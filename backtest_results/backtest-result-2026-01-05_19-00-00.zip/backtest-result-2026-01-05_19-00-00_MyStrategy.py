from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class MyStrategy(IStrategy):

    timeframe = '1h'

    # Tighter stop loss (3% instead of 10%)
    stoploss = -0.03

    # Trailing stop to lock in profits
    trailing_stop = True
    trailing_stop_positive = 0.01  # Start trailing at 1% profit
    trailing_stop_positive_offset = 0.02  # Activate trailing at 2% profit
    trailing_only_offset_is_reached = True

    # Tiered ROI - take profits gradually
    minimal_roi = {
        "0": 0.04,   # 4% profit anytime
        "30": 0.025, # 2.5% after 30 min
        "60": 0.015, # 1.5% after 1 hour
        "120": 0.01  # 1% after 2 hours
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI for overbought/oversold
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # EMAs for trend direction
        dataframe['ema_fast'] = ta.EMA(dataframe, timeperiod=8)
        dataframe['ema_slow'] = ta.EMA(dataframe, timeperiod=21)

        # Volume confirmation
        dataframe['volume_mean'] = dataframe['volume'].rolling(window=20).mean()

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Entry conditions:
        # 1. RSI oversold but starting to recover (between 25-35)
        # 2. Fast EMA above slow EMA (uptrend)
        # 3. Volume above average (confirmation)
        dataframe.loc[
            (dataframe['rsi'] > 25) &
            (dataframe['rsi'] < 35) &
            (dataframe['ema_fast'] > dataframe['ema_slow']) &
            (dataframe['volume'] > dataframe['volume_mean']),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Exit when RSI overbought or trend reverses
        dataframe.loc[
            (dataframe['rsi'] > 70) |
            (dataframe['ema_fast'] < dataframe['ema_slow']),
            'exit_long'] = 1

        return dataframe