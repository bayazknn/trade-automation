from freqtrade.strategy import IStrategy
from pandas import DataFrame
import talib.abstract as ta

class MyStrategy(IStrategy):

    timeframe = '1h'

    # Tighter stop loss (5% instead of 10%)
    stoploss = -0.05

    # Trailing stop to lock in profits
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    # Tiered ROI
    minimal_roi = {
        "0": 0.03,
        "60": 0.02,
        "180": 0.01
    }

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # EMAs
        dataframe['ema_9'] = ta.EMA(dataframe, timeperiod=9)
        dataframe['ema_21'] = ta.EMA(dataframe, timeperiod=21)

        # MACD for momentum
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macd_signal'] = macd['macdsignal']

        # Bollinger Bands for volatility
        bollinger = ta.BBANDS(dataframe, timeperiod=20)
        dataframe['bb_lower'] = bollinger['lowerband']
        dataframe['bb_upper'] = bollinger['upperband']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Entry: RSI oversold + price near lower BB + MACD crossing up
        dataframe.loc[
            (
                (dataframe['rsi'] < 40) &
                (dataframe['close'] < dataframe['bb_lower'] * 1.02) &
                (dataframe['macd'] > dataframe['macd_signal'])
            ) |
            (
                (dataframe['rsi'] < 35) &
                (dataframe['ema_9'] > dataframe['ema_21']) &
                (dataframe['macd'] > dataframe['macd_signal'])
            ),
            'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # Exit: RSI overbought or price near upper BB
        dataframe.loc[
            (dataframe['rsi'] > 70) |
            (dataframe['close'] > dataframe['bb_upper'] * 0.99),
            'exit_long'] = 1

        return dataframe