from freqtrade.strategy import IStrategy, IntParameter, DecimalParameter, CategoricalParameter
from pandas import DataFrame
from functools import reduce
import talib.abstract as ta

class HyperoptStrategy(IStrategy):
    """
    Strategy with hyperoptable parameters for optimization.
    """

    timeframe = '1h'

    # Hyperoptable stoploss
    stoploss = -0.05

    # Trailing stop parameters (will be optimized)
    trailing_stop = True
    trailing_stop_positive = 0.01
    trailing_stop_positive_offset = 0.015
    trailing_only_offset_is_reached = True

    # ROI table (will be optimized)
    minimal_roi = {
        "0": 0.03,
        "60": 0.02,
        "180": 0.01
    }

    # Hyperoptable parameters for entry
    buy_rsi = IntParameter(20, 45, default=35, space="buy", optimize=True)
    buy_rsi_enabled = CategoricalParameter([True, False], default=True, space="buy", optimize=True)

    buy_bb_enabled = CategoricalParameter([True, False], default=True, space="buy", optimize=True)
    buy_bb_factor = DecimalParameter(0.98, 1.05, default=1.02, decimals=2, space="buy", optimize=True)

    buy_macd_enabled = CategoricalParameter([True, False], default=True, space="buy", optimize=True)

    buy_ema_short = IntParameter(5, 15, default=9, space="buy", optimize=True)
    buy_ema_long = IntParameter(15, 30, default=21, space="buy", optimize=True)
    buy_ema_enabled = CategoricalParameter([True, False], default=False, space="buy", optimize=True)

    # Hyperoptable parameters for exit
    sell_rsi = IntParameter(60, 85, default=70, space="sell", optimize=True)
    sell_rsi_enabled = CategoricalParameter([True, False], default=True, space="sell", optimize=True)

    sell_bb_enabled = CategoricalParameter([True, False], default=True, space="sell", optimize=True)
    sell_bb_factor = DecimalParameter(0.95, 1.02, default=0.99, decimals=2, space="sell", optimize=True)

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        # RSI
        dataframe['rsi'] = ta.RSI(dataframe, timeperiod=14)

        # EMAs - calculate range for hyperopt
        for val in self.buy_ema_short.range:
            dataframe[f'ema_{val}'] = ta.EMA(dataframe, timeperiod=val)
        for val in self.buy_ema_long.range:
            dataframe[f'ema_{val}'] = ta.EMA(dataframe, timeperiod=val)

        # MACD
        macd = ta.MACD(dataframe)
        dataframe['macd'] = macd['macd']
        dataframe['macd_signal'] = macd['macdsignal']

        # Bollinger Bands
        bollinger = ta.BBANDS(dataframe, timeperiod=20)
        dataframe['bb_lower'] = bollinger['lowerband']
        dataframe['bb_upper'] = bollinger['upperband']

        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # RSI condition
        if self.buy_rsi_enabled.value:
            conditions.append(dataframe['rsi'] < self.buy_rsi.value)

        # Bollinger Band condition
        if self.buy_bb_enabled.value:
            conditions.append(dataframe['close'] < dataframe['bb_lower'] * self.buy_bb_factor.value)

        # MACD condition
        if self.buy_macd_enabled.value:
            conditions.append(dataframe['macd'] > dataframe['macd_signal'])

        # EMA condition
        if self.buy_ema_enabled.value:
            conditions.append(
                dataframe[f'ema_{self.buy_ema_short.value}'] > dataframe[f'ema_{self.buy_ema_long.value}']
            )

        # Volume check
        conditions.append(dataframe['volume'] > 0)

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'enter_long'] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        conditions = []

        # RSI condition
        if self.sell_rsi_enabled.value:
            conditions.append(dataframe['rsi'] > self.sell_rsi.value)

        # Bollinger Band condition
        if self.sell_bb_enabled.value:
            conditions.append(dataframe['close'] > dataframe['bb_upper'] * self.sell_bb_factor.value)

        # Volume check
        conditions.append(dataframe['volume'] > 0)

        if conditions:
            dataframe.loc[
                reduce(lambda x, y: x & y, conditions),
                'exit_long'] = 1

        return dataframe
